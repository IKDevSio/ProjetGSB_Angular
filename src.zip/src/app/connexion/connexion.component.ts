import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import {ClientService} from '../service/client.service';
import {Utilisateur} from '../metier/utilisateur';
import { MD5Service } from '../outils/md5Servicve';


@Component({
  selector: 'app-connexion',
  templateUrl: './connexion.component.html',
  styleUrls: ['./connexion.component.css']
})
export class ConnexionComponent implements OnInit {

   private titre : string = 'Connexion';
   private userLogin  : string ;
   private userMdp : string ;
   private lblMdp : string = 'Entrez votre mot de passe :';
   private lblLogin : string  = 'login :';
   private lblMessage : string ;
   private estCache : boolean = true;
   private unUtilisateur : Utilisateur;
   private error : string = '';
   private unMD5S: MD5Service;

   constructor(private unCS : ClientService, private router: Router) { }

  
  ngOnInit() {
  }
  valider() : void  {

     let pwdmd5 : string;
     this.unMD5S= new MD5Service();

    this.unCS.getLogin(this.userLogin).subscribe (
      
     (uti)  => {this.unUtilisateur = uti ;},
      (error) => {this.error = error.messages; },
      () =>{  if (this.error != undefined)
              {
    
                try
                    {
                      pwdmd5 = this.unMD5S.createHash(this.userMdp);
                      if (this.unUtilisateur.motPasse == pwdmd5)
                         {
                            alert("Authentification réussie !!!");
                            this.router.navigate(['accueil']);
                          }
                      else
                         alert ("Mot de passe erroné !!!");
                    } 
          
                 catch (err ) {
                       alert( "Erreur d'appel!");
                 }
               }
                 else
                   alert( "Erreur sur le login " + this.error);
        }
    ) 
    {
    }
 
 }
}
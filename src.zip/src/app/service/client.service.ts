import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/observable';
import 'rxjs/add/operator/toPromise' ;
import 'rxjs/add/operator/map' ;
import { Client } from '../metier/client';
import { Utilisateur } from '../metier/utilisateur';
import { HttpHeaders } from '@angular/common/http'; 


// const    ENDPOINT = "http://192.168.225.121:8080/";
 const    ENDPOINT = "http://localhost:8080/ProjetCerisaie/";

@Injectable()
export class ClientService {
  

 private headers = new Headers( {'content-type' : 'application/json'} );



private ClientUrl : string;


constructor(private httpClient : HttpClient) {

  let httpHeaders = new HttpHeaders({
    'Content-Type' : 'application/json',
    'Cache-Control': 'no-cache'
}); 
 }

getClientsListe() : Observable<any>
 {

  this.ClientUrl= ENDPOINT + 'Client/getClients';  
  return this.httpClient.get(this.ClientUrl);

}

getLogin(nom : string) : Observable<Utilisateur>
{

 this.ClientUrl= ENDPOINT + 'authentification/getLogin/'+nom;  
 return this.httpClient.get<Utilisateur>(this.ClientUrl);

}


// Modification d'un client

// On recherche le client 

getClientId(id : number) : Observable<Client>
{

 this.ClientUrl= ENDPOINT + 'Client/getUnClient/'+id;
 return this.httpClient.get<Client>(this.ClientUrl);

}

// On modifie un client
updateClient ( unC : Client) : Observable<any>
{
  this.ClientUrl= ENDPOINT + 'Client/modification' ;
 
  let httpHeaders = new HttpHeaders({
    'Content-Type' : 'application/json',
    'Cache-Control': 'no-cache'
       });    
       let options = {
    headers: httpHeaders
       };        

  return this.httpClient.post(this.ClientUrl,JSON.stringify(unC), options);
}


private handleError (error: Response | any) {
  // In a real world app, you might use a remote logging infrastructure
  let errMsg: string;
  if (error instanceof Response) {
    const body = error.json() || '';
    const err =  JSON.stringify(body);
    errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
  } else {
    errMsg = error.message ? error.message : error.toString();
  }
  console.error(errMsg);
  return Promise.reject(error.message || error);
}
}

import { Component, OnInit } from '@angular/core';
import { Client } from '../metier/client';

import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { ClientService } from '../service/client.service';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})

export class ClientComponent implements OnInit {
  private unClient: Client;
  private client_id: number;
  private titre: string = 'Modification d\'un client  de la Cerisaie';
  private paramMap: ParamMap;
  private error: string ='';

  constructor(private unCS: ClientService,
    private activatedRoute: ActivatedRoute, private unRouteur: Router ) { }

  ngOnInit() {
    
    this.client_id = +this.activatedRoute.snapshot.paramMap.get('numCli');
    this.getClient(this.client_id);
  }

  getClient(id: number) : void {

    this.unCS.getClientId(id).subscribe(
      (client) => { this.unClient = client; },
      (error) => { this.error = error.messages; }
    )
   
  }



  // On appelle le service pour enregistrer le visiteur

  valider(): void {


    this.unCS.updateClient(this.unClient). subscribe(
      () => {
       
      },
      (error) => { this.error = error.messages; }
      );

      if (this.error!='')
        alert( "Erreur survenue " + this.error);
      else
        alert( "Modification réussie !");

    this.unRouteur.navigate(['/accueil']);

  }

  annuler(): void {
    this.unRouteur.navigate(['/accueil']);

  }



 

}


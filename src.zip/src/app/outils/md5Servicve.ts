import { Injectable }    from '@angular/core';
import {md5} from './md5'; 

@Injectable()
export class MD5Service {
 
  public  createHash(mdp: string) : string {
    return md5(mdp);
  }
}
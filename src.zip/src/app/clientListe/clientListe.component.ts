import { Component, OnInit } from '@angular/core';
import { Client } from '../metier/client';
import {ClientService} from '../service/client.service';

import {Router} from '@angular/router';


@Component({
  selector: 'app-client',
  templateUrl: './clientListe.component.html',
  styleUrls: ['./clientListe.component.css']
})
export class ClientListeComponent implements OnInit {
 private mesClients : Client[];
 private error : string;


  titre = 'Liste des clients de la Cerisaie ';
  constructor(  private unCS : ClientService, private unRouteur : Router)  { 
  }

  ngOnInit() {
    this.getClients();
  }

  getClients() : void {

   this.unCS.getClientsListe().subscribe (
         
     (clients)  => {this.mesClients = clients ;},
     (error) => {this.error = error.messages; }
         
   )  
  }
  
  modifier(numCli: number) : void  {
    this.unRouteur.navigate(['/modifierClient/'+ numCli]);
  }
}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule,Routes } from '@angular/router';

import { ClientListeComponent } from '../clientListe/clientListe.component';
import { ClientComponent } from '../client/client.component';
import { NavbarComponent } from '../navbar/navbar.component';
import { ConnexionComponent } from '../connexion/connexion.component';


const routes : Routes =  [

  { path: '', redirectTo : '/connexion', pathMatch: 'full'  },
  { path: 'connexion', component: ConnexionComponent },
  { path: 'client', component: ClientComponent },
  { path: 'clientsListe', component: ClientListeComponent },
  { path: 'modifierClient/:numCli', component: ClientComponent },
  { path: 'accueil', component: NavbarComponent }
]


@NgModule({
    imports:  [RouterModule.forRoot(routes)],
    exports: [RouterModule] 
})
export class AppRoutingModule { }

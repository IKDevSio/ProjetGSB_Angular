export class Client {
    
   

    public  numCli : number;
    public  nomCli : string;
    public  adrRueCli: string;
    public  cpCli: string;
    public  villeCli: string;
    public  pieceCli: string;
    public numPieceCli: string;
    }
       

        
    
    

  
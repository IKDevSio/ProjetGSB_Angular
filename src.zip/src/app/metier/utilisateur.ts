export class Utilisateur {
    
    public  numUtil : number;
    public  nomUtil : string;
    public  motPasse : string;
    public  role : string;

    }

  
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms'; // <-- NgModel ici
import { AppComponent } from './app.component';
import { ConnexionComponent } from './connexion/connexion.component';
import { NavbarComponent } from './navbar/navbar.component';

import { ClientListeComponent } from './clientListe/clientListe.component';
import { AppRoutingModule } from './app-routing/app-routing.module';
import { HttpClientModule } from '@angular/common/http'; 

 import { ClientService } from './service/client.service';
 import { ClientComponent } from './client/client.component'; // <-- NgModel ici


 
 


@NgModule({
  declarations: [
    AppComponent,
     ConnexionComponent,
     NavbarComponent,
     ClientComponent,
     ClientListeComponent
     
  ],
  imports: [
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  
  ],
   providers: [ClientService],
  bootstrap: [AppComponent]
})
export class AppModule { }




